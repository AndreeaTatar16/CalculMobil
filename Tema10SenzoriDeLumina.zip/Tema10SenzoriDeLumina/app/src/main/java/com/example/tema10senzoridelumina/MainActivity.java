package com.example.tema10senzoridelumina;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private TextView lightValueTV;
    private SensorManager sensorManager;
    private List<Sensor> deviceSensorList;
    Sensor lightSensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lightValueTV = findViewById(R.id.lightValueTV);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        deviceSensorList = sensorManager.getSensorList(Sensor.TYPE_ALL);

        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        if(lightSensor == null){
            Toast.makeText(this, "No light sensor found", Toast.LENGTH_LONG).show();
            finish();
        }else{
            sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_LIGHT){
            lightValueTV.setText("Light intensity \n "+ sensorEvent.values[0]);
        }

        float lightLevel = sensorEvent.values[0];

        //preiau luminozitatea de la telefon
        WindowManager.LayoutParams layout = getWindow().getAttributes();
        layout.screenBrightness = lightLevel / (float) lightSensor.getMaximumRange();
        getWindow().setAttributes(layout);

       // float screenBrightness = (float) Math.pow((lightLevel / lightSensor.getMaximumRange()), 2) * 255;

//        if(lightLevel > 0 && lightLevel < 50)
//            layout.screenBrightness = 0.01f;
//        else if(lightLevel >= 50 || lightLevel < 100)
//            layout.screenBrightness = 0.1f;
//        else if(lightLevel > 100 && lightLevel < 200)
//            layout.screenBrightness = 0.2f;
//        else if(lightLevel > 200 && lightLevel < 300)
//            layout.screenBrightness = 0.3f;
//        else if(lightLevel > 300 && lightLevel < 400)
//            layout.screenBrightness = 0.4f;
//        else if(lightLevel > 400 && lightLevel < 500)
//            layout.screenBrightness = 0.5f;
//        else if(lightLevel > 500 && lightLevel < 600)
//            layout.screenBrightness = 0.6f;
//        else if(lightLevel > 600 && lightLevel < 700)
//            layout.screenBrightness = 0.7f;
//        else if(lightLevel > 700 && lightLevel < 800)
//            layout.screenBrightness = 0.8f;
//        else if(lightLevel > 800 && lightLevel < 900)
//            layout.screenBrightness = 0.9f;
//        else if(lightLevel > 900 && lightLevel < 1000)
//            layout.screenBrightness = 1.0f;

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    protected void onStop() {
        super.onStop();
        sensorManager.unregisterListener(this);
    }
}