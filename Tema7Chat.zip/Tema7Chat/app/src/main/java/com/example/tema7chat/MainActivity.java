package com.example.tema7chat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {

    TextView clientTV;
    TextView messageFromServerTV;
    EditText serverAddressInput;
    EditText serverPortInput;
    EditText sendToServerInput;

    //int serverPort;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        clientTV = findViewById(R.id.clientTV);
        messageFromServerTV = findViewById(R.id.messageFromServerTV);
        serverAddressInput = findViewById(R.id.serverAddressInput);
        serverPortInput = findViewById(R.id.serverPortInput);
        sendToServerInput = findViewById(R.id.sendToServerInput);
    }

    private ClientThread clientThread;

    //functia care realizeaza conectarea cu serverul
    public void connectWithServer(View view){
        clientThread = new ClientThread();
        clientThread.startClient();
        //clientThread.receive();
    }

//    public void primesteMesaje(View view){
//        clientThread.receive();
//    }

    //trimiterea mesajelor catre server
    public void sendMessage(View view){
            String msg = sendToServerInput.getText().toString(); //preia textul
            clientThread.send(msg);  //apeleaza metoda send din clasa ClientThread
    }

    //clasa ClientThread care va fi responsabila de trimiterea si primirea mesajelor de la server
    class ClientThread extends Thread implements Runnable{
        private boolean clientIsRunning;   //variabila care verifica daca clientul ruleaza
        private Socket socket;   //socketul responsabil cu conectarea

        String serverName = serverAddressInput.getText().toString();
        int serverPort = Integer.parseInt(serverPortInput.getText().toString());

        //se porneste threadul pentru a permite conectarea la server
        public void startClient(){
            clientIsRunning = true;
            start();
        }

        public Socket getSocket(){
            return socket;
        }

        //functia de primire a mesajelor
        public void receive(){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        while(clientIsRunning) {
                            //cu bufferedReader(Input) initializez un canal de comunicare pentru a vedea ceea ce primesc de la socket
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            String textReceived = bufferedReader.readLine();   //citesc mesajul

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    messageFromServerTV.setText(textReceived);   //afisez la main thread mesajul care a venit
                                }
                            });
                        }
                    }  catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }

        //functia de trimitere a mesajelor, care este un Thread separat
        public void send(String message){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        //trimit la server mesajul prin socket
                        PrintWriter output = new PrintWriter(socket.getOutputStream());
                        output.write(message);
                        output.flush();
                        socket.close();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }

        //pentru a verifica daca clientul s-a conectat la server prin socketul indicat, afisez in interfata mesajul din runOnUiThread
        @Override
        public void run() {
            try{
                socket = new Socket(serverName, serverPort);
                while (clientIsRunning){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            messageFromServerTV.setText("comunica cu serverul");
                        }
                    });
                }

            }  catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}