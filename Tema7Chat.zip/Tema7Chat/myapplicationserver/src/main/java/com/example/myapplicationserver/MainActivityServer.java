package com.example.myapplicationserver;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class MainActivityServer extends AppCompatActivity {

    private static final String TAG = "MainActivityServer";
    private TextView serverTV, messageFromClientTV, serverAddresstv, serverPortTV;
    private String serverIP = "10.0.2.16";   //ip-ul telefonului din setarile emulatorului
    private int serverPort = 1234;   //portul de comunicare
    private EditText sendToClientInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_server);

        serverTV = findViewById(R.id.serverTV);
        messageFromClientTV = findViewById(R.id.messageFromClientTV);
        serverAddresstv = findViewById(R.id.serverAddresstv);
        serverPortTV = findViewById(R.id.serverPortTV);
        sendToClientInput = findViewById(R.id.sendToClientInput);

        serverAddresstv.setText(serverIP);
        serverPortTV.setText(String.valueOf(serverPort));
    }

    private ServerThread serverThread;

    //pornesc threadul care realizeaza conexiunea
    public void connectWithClient(View view){
        serverThread = new ServerThread();
        serverThread.startServer();
    }

    public void send(View view){
        serverThread.sendMessage();
    }

    public void stopConnection(View view){
        serverThread.stopServer();
    }

    //similar cum am facut la Client, am facut 2 threaduri, unul pentru primirea mesajelor, si celalalt pentru trimitere la client
    class ServerThread extends Thread implements Runnable{
        private boolean serverIsRunning;
        private ServerSocket serverSocket;

        public void startServer(){
            serverIsRunning = true;
            start();
        }

        public void sendMessage(){
            String messageToSend = "ceva de trimis";
                    //sendToClientInput.getText().toString();
            Log.i(TAG, "sendMessage: " + messageToSend);

            try {
                Socket socket = serverSocket.accept();
                while(serverIsRunning){
                    PrintWriter outputServer = new PrintWriter(socket.getOutputStream());
                    outputServer.write(messageToSend);
                    outputServer.flush();

                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

//        public void receiveMessage(){
//
//        }

        @Override
        public void run() {
            try {
                serverSocket = new ServerSocket(serverPort);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        messageFromClientTV.setText("incerc sa ma conectez cu clientul");
                    }
                });
                while (serverIsRunning){
                    Socket socket = serverSocket.accept();   //instructiune blocanta, socketul va astepta conexiuni, altfel nu se executa mai departe codul
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //in momentul realizarii conexiunii cu clientul, afisez datele clientului
                            messageFromClientTV.setText("comunica cu clientul: " + socket.getInetAddress() + socket.getLocalPort());
                        }
                    });

                    socket.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        //apasarea butonului Stop Server inchide socketul, iar acesta nu va mai accepta conexiunik
        public void stopServer(){
            serverIsRunning = false;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    if(serverSocket != null){
                        try {
                            serverSocket.close();

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivityServer.this, "Server is stopped", Toast.LENGTH_SHORT).show();
                                }
                            });
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
        }
    }
}