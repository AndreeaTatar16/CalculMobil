package com.example.tema6servicii;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText periodInput;
    private EditText durationInput;
    private EditText volumeInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void playSound(View view){
        periodInput = findViewById(R.id.periodInput);
        durationInput = findViewById(R.id.durationInput);
        volumeInput = findViewById(R.id.volumeInput);

        String volume = volumeInput.getText().toString();
        int volumeInt = Integer.parseInt(volume);

        String period = periodInput.getText().toString();
        int periodInt = Integer.parseInt(period);

        String duration = durationInput.getText().toString();
        int durationInt = Integer.parseInt(duration);

        Intent intent1 = new Intent(getApplicationContext(), MyService.class);
        intent1.putExtra("period", period);
        intent1.putExtra("volume", volume);
        intent1.putExtra("duration", duration);

        startService(intent1);
    }

    public void stopService(View view){
        Intent intent2 = new Intent(getApplicationContext(), MyService.class);
        stopService(intent2);
    }
}