package com.example.tema6servicii;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MyService extends Service {

    private static final String TAG = "MyService";

    public MyService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(MyService.this, "A pornit service", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String receivedVolume = intent.getStringExtra("volume");
        String receivedPeriod = intent.getStringExtra("period");
        String receivedDuration = intent.getStringExtra("duration");

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(Long.parseLong(receivedPeriod) * 1000);   //threadul porneste sunetul dupa perioada selectata de user
                }catch (InterruptedException e){
                    e.printStackTrace();
                }

                //clasa MediaPlayer care genereaza sunetul
                final MediaPlayer mp = MediaPlayer.create(getApplicationContext(), R.raw.meow);
                //setarea volumului pe ambele parti ale difuzorului
                mp.setVolume(Float.parseFloat(receivedVolume)/1000, Float.parseFloat(receivedVolume)/1000);
                //cu Timer am folosit functia schedule pentru a seta durata sunetului, cate secunde sa tina sunetul
               new Timer().schedule(new TimerTask() {
                   @Override
                   public void run() {
                        mp.stop();
                        mp.release();
                   }
               }, Integer.parseInt(receivedDuration));
                mp.start();   //pornirea sunetului
                }
        };

        Thread serviceTaskIsOwnThread = new Thread(runnable);
        serviceTaskIsOwnThread.start();

        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        android.os.Process.killProcess(android.os.Process.myPid());
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }
}