package com.example.tema1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickButton(View view){
        TextView textShowingInfo = findViewById(R.id.nameTV);
        TextView emailTV = findViewById(R.id.emailTV);
        EditText editName = findViewById(R.id.editName);
        EditText editSurname = findViewById(R.id.editSurname);
        EditText editEmail = findViewById(R.id.editEmail);
        textShowingInfo.setText("Hello dear " + editName.getText().toString() + editSurname.getText().toString());
        emailTV.setText("Your email is " + editEmail.getText().toString());

        Context context = getApplicationContext();
        CharSequence text = "Your data are successfully registered!";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }

    public void onClickShowToast(View view){
        Toast.makeText(getApplicationContext(), "This is the toast", Toast.LENGTH_SHORT).show();
    }
}