package com.example.tema4listview;

public class Student {

    private String studentName;
    private String studentSurname;
    private String group;

    public Student(String studentName, String studentSurname, String group) {
        this.studentName = studentName;
        this.studentSurname = studentSurname;
        this.group = group;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentSurname() {
        return studentSurname;
    }

    public void setStudentSurname(String studentSurname) {
        this.studentSurname = studentSurname;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }
}
