package com.example.tema4listview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter implements ListAdapter {

    private ArrayList<Student> students;
    private Context context;

    public CustomAdapter(ArrayList<Student> students, Context context) {
        this.students = students;
        this.context = context;
    }

    @Override
    public int getCount(){
        return students.size();
    }

    @Override
    public Object getItem(int position) {
        return students.get(position);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

//    @Override
//    public long getItemId(int i) {
//        return students.get(i).get;
//    }

    //
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.custom_layout, null);
        }

        TextView tvName = view.findViewById(R.id.tvName);
        TextView tvSurname = view.findViewById(R.id.tvSurname);
        TextView tvGroup = view.findViewById(R.id.tvGroup);
        tvName.setText(students.get(position).getStudentName());
        tvSurname.setText(students.get(position).getStudentSurname());
        tvGroup.setText(students.get(position).getGroup());

        Button btnDelete = view.findViewById(R.id.btnDelete);

        btnDelete = view.findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "Item deleted: " + students.get(position).getStudentName() + " " + students.get(position).getStudentSurname(), Toast.LENGTH_SHORT).show();
                students.remove(position);  //sterg studentul dupa pozitia din lista
                notifyDataSetChanged();    //actualizez lista
            }
        });

        return view;
    }
}

