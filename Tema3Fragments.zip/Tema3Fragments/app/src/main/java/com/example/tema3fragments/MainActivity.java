package com.example.tema3fragments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import javax.security.auth.login.LoginException;

public class MainActivity extends AppCompatActivity {

    int i = 0;
    int contor = 0;
    private static final String TAG = "MyApp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnLeft = findViewById(R.id.btnLeft);

        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(i==0){
                    ImageFragment2 imageFragment2 = new ImageFragment2();
                    replaceFragment(imageFragment2);
                    i++;
                    contor = 2;
                }
                else if(i==1){
                    ImageFragment3 imageFragment3 = new ImageFragment3();
                    replaceFragment(imageFragment3);
                    i++;
                    contor = 3;
                }
                else if(i==2){
                    ImageFragment4 imageFragment4 = new ImageFragment4();
                    replaceFragment(imageFragment4);
                    i++;
                    contor = 4;
                }
                else if(i==3){
                    ImageFragment5 imageFragment5 = new ImageFragment5();
                    replaceFragment(imageFragment5);
                    i++;
                    contor = 5;
                }
                else if(i==4){
                    ImageFragment1 imageFragment1 = new ImageFragment1();
                    replaceFragment(imageFragment1);
                    i = 0;
                    contor = 1;
                }
            }
        });

        Button btnRight = findViewById(R.id.btnRight);
        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(i == 0){
                    ImageFragment5 imageFragment5 = new ImageFragment5();
                    replaceFragment(imageFragment5);
                    i = 4;
                    contor = 5;
                }
                else if (i == 1){
                    ImageFragment1 imageFragment1 = new ImageFragment1();
                    replaceFragment(imageFragment1);
                    i--;
                    contor = 1;
                }
                else if (i == 2){
                    ImageFragment2 imageFragment2 = new ImageFragment2();
                    replaceFragment(imageFragment2);
                    i--;
                    contor = 2;
                }
                else if (i == 3){
                    ImageFragment3 imageFragment3 = new ImageFragment3();
                    replaceFragment(imageFragment3);
                    i--;
                    contor = 3;
                }
                else if (i == 4){
                    ImageFragment4 imageFragment4 = new ImageFragment4();
                    replaceFragment(imageFragment4);
                    i--;
                    contor = 4;
                }
            }
        });

        Button btnDetails = findViewById(R.id.btnDetails);
        btnDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (contor)
                {
                    case 1:
                        DetailsFragment1 detailsFragment1 = new DetailsFragment1();
                        replaceFragment(detailsFragment1);
                        Log.i(TAG, "am ajuns in details 1");
                        break;
                    case 2:
                        DetailsFragment2 detailsFragment2 = new DetailsFragment2();
                        replaceFragment(detailsFragment2);
                        Log.i(TAG, "am ajuns in details 2");
                        break;
                    case 3:
                        DetailsFragment3 detailsFragment3 = new DetailsFragment3();
                        replaceFragment(detailsFragment3);
                        Log.i(TAG, "am ajuns in details 3");
                        break;
                    case 4:
                        DetailsFragment4 detailsFragment4 = new DetailsFragment4();
                        replaceFragment(detailsFragment4);
                        Log.i(TAG, "am ajuns in details 4");
                        break;
                    case 5:
                        DetailsFragment5 detailsFragment5 = new DetailsFragment5();
                        replaceFragment(detailsFragment5);
                        Log.i(TAG, "am ajuns in details 5");
                        break;
                    default:
                        Log.i(TAG, "onClick: aici e default");
                }
            }
        });
    }


    public void replaceFragment(Fragment frParam){
        FragmentManager frManager = getSupportFragmentManager();
        FragmentTransaction frTransaction = frManager.beginTransaction();
        frTransaction.replace(R.id.fragmentContainerView3, frParam, null);
        frTransaction.setReorderingAllowed(true);
        frTransaction.addToBackStack("name");
        frTransaction.commit();
    }
}