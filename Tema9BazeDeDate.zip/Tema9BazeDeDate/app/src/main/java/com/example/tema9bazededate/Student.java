package com.example.tema9bazededate;

public class Student {
    private int id;
    private String studentName;
    private String studentSurname;
    private int studentAge;

    public Student(int id, String name, String surname, int age) {
        this.id = id;
        this.studentName = name;
        this.studentSurname = surname;
        this.studentAge = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + studentName + '\'' +
                ", surname='" + studentSurname + '\'' +
                ", age=" + studentAge +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentSurname() {
        return studentSurname;
    }

    public void setStudentSurname(String studentSurname) {
        this.studentSurname = studentSurname;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public void setStudentAge(int studentAge) {
        this.studentAge = studentAge;
    }
}
