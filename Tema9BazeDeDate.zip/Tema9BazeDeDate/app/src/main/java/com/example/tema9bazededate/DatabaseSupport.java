package com.example.tema9bazededate;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseSupport extends SQLiteOpenHelper {

    public static final String STUDENT_TABLE = "STUDENT_TABLE";
    public static final String COLUMN_STUDENT_ID = "STUDENT_ID";
    public static final String COLUMN_STUDENT_NAME = "STUDENT_NAME";
    public static final String COLUMN_STUDENT_SURNAME = "STUDENT_SURNAME";
    public static final String COLUMN_STUDENT_AGE = "STUDENT_AGE";

    public DatabaseSupport(@Nullable Context context) {
        super(context, "students.ds", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String command = "CREATE TABLE " + STUDENT_TABLE +
                " (" + COLUMN_STUDENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
                + COLUMN_STUDENT_NAME + " TEXT , "
                + COLUMN_STUDENT_SURNAME + " TEXT ," +
                COLUMN_STUDENT_AGE + " INT ); ";
        sqLiteDatabase.execSQL(command);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    public boolean addStudent(Student student) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_STUDENT_NAME, student.getStudentName());
        contentValues.put(COLUMN_STUDENT_SURNAME, student.getStudentSurname());
        contentValues.put(COLUMN_STUDENT_AGE, student.getStudentAge());

        long insert = database.insert(STUDENT_TABLE, null, contentValues);
        if (insert == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean deleteStudent(Student Student) {
        SQLiteDatabase database = this.getWritableDatabase();
        String command = "DELETE FROM " + STUDENT_TABLE + " WHERE " + COLUMN_STUDENT_ID + " = " + Student.getId();
        Cursor cursor = database.rawQuery(command, null);
        if (cursor.moveToFirst()) {
            return true;
        } else {
            return false;
        }
    }

    public boolean searchStudent(String column, String item) {
        SQLiteDatabase database = this.getWritableDatabase();
        String command = "SELECT * FROM " + STUDENT_TABLE + " WHERE " + column + " = " + "'" + item + "'";
        Cursor cursor = database.rawQuery(command, null);
        if (cursor.moveToFirst()) {
            return true;
        } else {
            return false;
        }
    }

    public List<Student> getAll() {
        List<Student> studentList = new ArrayList<>();

        String command = "SELECT * FROM " + STUDENT_TABLE;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(command, null);
        if (cursor.moveToFirst()) {
            do {
                int studentId = cursor.getInt(0);
                String studentName = cursor.getString(1);
                String studentSurname = cursor.getString(2);
                int studentAge = cursor.getInt(3);
                Student student = new Student(studentId, studentName, studentSurname, studentAge);
                studentList.add(student);
            } while (cursor.moveToNext());
        }
        cursor.close();
        database.close();
        return studentList;
    }

    public List<Student> getOne(String column, String item) {
        List<Student> studentList = new ArrayList<>();

        String command = "SELECT * FROM " + STUDENT_TABLE + " WHERE " + column + " = " + "'" + item + "'";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(command, null);
        if (cursor.moveToFirst()) {
            do {
                int studentId = cursor.getInt(0);
                String studentName = cursor.getString(1);
                String studentSurname = cursor.getString(2);
                int studentAge = cursor.getInt(3);
                Student student = new Student(studentId, studentName, studentSurname, studentAge);
                studentList.add(student);
            } while (cursor.moveToNext());
        }
        cursor.close();
        database.close();
        return studentList;
    }
}
