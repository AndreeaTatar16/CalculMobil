package com.example.tema9bazededate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ArrayAdapter arrayAdapter;
    DatabaseSupport databaseSupport;
    Student selectedStudent;
    private TextView studentTV;
    private EditText studentNameInput, studentSurnameInput, studentAgeInput;
    private ListView studentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        studentTV = findViewById(R.id.studentTV);
        studentNameInput = findViewById(R.id.studentNameInput);
        studentSurnameInput = findViewById(R.id.studentSurnameInput);
        studentAgeInput = findViewById(R.id.studentAgeInput);
        studentList = findViewById(R.id.studentList);

        databaseSupport = new DatabaseSupport(MainActivity.this);
        arrayAdapter = new ArrayAdapter<Student>(MainActivity.this, android.R.layout.simple_list_item_1, databaseSupport.getAll());
        studentList.setAdapter(arrayAdapter);

        //preia datele unui student din lista cand este apasat
        studentList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                selectedStudent = (Student) adapterView.getItemAtPosition(position);
                studentNameInput.setText(selectedStudent.getStudentName());
                studentSurnameInput.setText(selectedStudent.getStudentSurname());
                studentAgeInput.setText(String.valueOf(selectedStudent.getStudentAge()));
            }
        });
    }

    //se adauga un nou student dupa datele din TextViewuri
    public void onCLickAdd(View view) {
        Student student = null;

        String name = studentNameInput.getText().toString();
        String surname = studentSurnameInput.getText().toString();
        int age = 0;

        if (!studentAgeInput.getText().toString().equals("")) {
            age = Integer.parseInt(studentAgeInput.getText().toString());
        }
        try {
            student = new Student(-1, name, surname, age);
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong...", Toast.LENGTH_SHORT).show();
        }
        boolean addedToDb = databaseSupport.addStudent(student);
        studentTV.setText("Student added in database:" + addedToDb); //true daca s-a adaugat in DB, false in caz contrar

        arrayAdapter = new ArrayAdapter<Student>(MainActivity.this, android.R.layout.simple_list_item_1, databaseSupport.getAll());
        studentList.setAdapter(arrayAdapter);
    }

    //functia de delete care preia studentul diin DB si il sterge
    public void onClickDelete(View view) {
        databaseSupport = new DatabaseSupport(MainActivity.this);
        if (selectedStudent != null) {
            databaseSupport.deleteStudent(selectedStudent);
            studentTV.setText("Student deleted from DB");
            arrayAdapter = new ArrayAdapter<Student>(MainActivity.this, android.R.layout.simple_list_item_1, databaseSupport.getAll());
            studentList.setAdapter(arrayAdapter);
        } else {
            Toast.makeText(this, "Select a student first!", Toast.LENGTH_SHORT).show();
        }
    }

    //functia de cautare dupa un anumit criteriu
    public void onClickSearch(View view) {
        databaseSupport = new DatabaseSupport(MainActivity.this);
        String name = studentNameInput.getText().toString();
        String surname = studentSurnameInput.getText().toString();
        int age = 0;
        if (!studentAgeInput.getText().toString().equals("")) {
            age = Integer.parseInt(studentAgeInput.getText().toString());
        }

        String column;
        if (!name.equals("")) {   //daca exista in campul nume, o valoare, caut un student dupa valoarea respectiva
            column = "STUDENT_NAME";
            databaseSupport.searchStudent(column, name);
            //caut in lista in coloana STUDENT_NAME, dupa inputul de la name
            arrayAdapter = new ArrayAdapter<Student>(MainActivity.this, android.R.layout.simple_list_item_1, databaseSupport.getOne(column, name));
            studentTV.setText("Student filtered by name");
        } else if (!surname.equals("")) {
            column = "STUDENT_SURNAME";
            databaseSupport.searchStudent(column, surname);
            arrayAdapter = new ArrayAdapter<Student>(MainActivity.this, android.R.layout.simple_list_item_1, databaseSupport.getOne(column, surname));
            studentTV.setText("Student filtered by surname");
        } else if (!studentAgeInput.getText().toString().equals("")) {
            column = "STUDENT_AGE";
            databaseSupport.searchStudent(column, studentAgeInput.getText().toString());
            arrayAdapter = new ArrayAdapter<Student>(MainActivity.this, android.R.layout.simple_list_item_1, databaseSupport.getOne(column, studentAgeInput.getText().toString()));
            studentTV.setText("Student filtered by age");
        } else {
            Toast.makeText(this, "Nothing to show...", Toast.LENGTH_SHORT).show();
            arrayAdapter = new ArrayAdapter<Student>(MainActivity.this, android.R.layout.simple_list_item_1, databaseSupport.getAll());
        }
        studentList.setAdapter(arrayAdapter);   //actualizeaza lista cu ce a gasit si il afiseaza
    }
}