package com.example.tema5threaduri;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private volatile boolean stopThread = false;

    private TextView infoTextView;
    private TextView winnerTextView;
    private TextView threadGeneratedNumber;

    private EditText minValue;
    private EditText maxValue;
    private EditText generatedNumber;

    private int randomInt;   //va retine pe tot parcursul programului numarul care va fi generat pentru a fi ghicit de user si thread

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        infoTextView = findViewById(R.id.infoTextView);
        winnerTextView = findViewById(R.id.winnerTextView);
        threadGeneratedNumber = findViewById(R.id.threadGeneratedNumber);
        minValue = findViewById(R.id.minValue);
        maxValue = findViewById(R.id.maxValue);
        generatedNumber = findViewById(R.id.generatedNumber);
    }

    //cand se porneste jocul, se va genera si numarul de ghicit
    public void newGame(View view) {
        stopThread = false;   //las threadul sa ruleze
        Random random = new Random();

        //valorile intervalului, min si max
        String minimumValue = minValue.getText().toString();
        int intMinValue = Integer.parseInt(minimumValue);

        String maximumValue = maxValue.getText().toString();
        int intMaxValue = Integer.parseInt(maximumValue);
        int randomInt = random.nextInt((intMaxValue - intMinValue) + 1) + intMinValue;  //va fi generat un numar intre min si max

        //pornesc threadul si va incepe sa ghiceasca numarul
        BackgroundThread backgroundThread = new BackgroundThread(randomInt, intMinValue, intMaxValue);
        new Thread(backgroundThread).start();
    }

    //verificarea numarului introdus de user
    public void checkNumber(View view) {
        stopThread = false;
        Random random = new Random();

        String minimumValue = minValue.getText().toString();
        int intMinValue = Integer.parseInt(minimumValue);

        String maximumValue = maxValue.getText().toString();
        int intMaxValue = Integer.parseInt(maximumValue);

        //numarul introdus de user
        int generatedNrInt = Integer.parseInt(generatedNumber.getText().toString());

        //se genereaza numarul de ghicit
        randomInt = random.nextInt((intMaxValue - intMinValue) + 1) + intMinValue;

        if (randomInt == generatedNrInt) {
            Toast.makeText(this, "User guessed the number", Toast.LENGTH_SHORT).show();
            winnerTextView.setText("User is the winner!");
            stopThread = true;
        }
    }

    //clasa care va avea un fir de executie care ruleaza in background
    class BackgroundThread implements Runnable {
        private final Handler mainHandler = new Handler();
        Random random = new Random();
        private int desiredNumber;
        private int minValue;
        private int maxValue;

        //constructorul clasei cu capetele intervalului, dar si cu numarul pe care trebuie sa il ghiceasca
        public BackgroundThread(int desiredNumber, int minValue, int maxValue) {
            this.desiredNumber = desiredNumber;
            this.minValue = minValue;
            this.maxValue = maxValue;
        }

        //firul secundar care ghiceste numarul
        @Override
        public void run() {
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (stopThread)
                        return;
                    //genereaza numere in intervalul selectat
                    int randomInt = random.nextInt((maxValue - minValue) + 1) + minValue;
                    mainHandler.postDelayed(this, 2000);  //odata la 2 secunde sa genereze cate un numar
                    String status = "Threadul a generat " + randomInt;
                    threadGeneratedNumber.setText(status);

                    if (randomInt == desiredNumber) {
                        Toast.makeText(MainActivity.this, "Thread guessed the number! ", Toast.LENGTH_SHORT).show();
                        winnerTextView.setText("Thread is the winner!");
                        stopThread = true;
                    }
                }
            });

        }
    }

}