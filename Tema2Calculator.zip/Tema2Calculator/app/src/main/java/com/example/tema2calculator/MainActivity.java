package com.example.tema2calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView resultBox = findViewById(R.id.resultBox);

        resultBox.setText("\n Rezultatul este: " + getIntent().getFloatExtra("resultKey", 0));
    }

    public void onClickSendData(View view){
        Intent intent1 =new Intent(this, MainActivity2.class);
        EditText firstNumber = findViewById(R.id.firstNumber);
        EditText secondNumber = findViewById(R.id.secondNumber);
        TextView resultBox = findViewById(R.id.resultBox);

        intent1.putExtra("numberKey1", firstNumber.getText().toString());
        intent1.putExtra("numberKey2", secondNumber.getText().toString());

        Toast.makeText(getApplicationContext(), "Going to activity2...", Toast.LENGTH_SHORT).show();
        startActivity(intent1);

        resultBox.setText("Primul numar = " + firstNumber.getText() + " Al doilea numar = " + secondNumber.getText());
    }
}