package com.example.tema2calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        String receivedNumber1 = getIntent().getStringExtra("numberKey1");
        String receivedNumber2 = getIntent().getStringExtra("numberKey2");

        TextView numbersReceived = findViewById(R.id.numbersReceived);

        numbersReceived.setText("Numbers received: " + receivedNumber1 + " " + receivedNumber2);
     }

     public void onClickAdd(View view){
        Intent intent2 = new Intent(this, MainActivity.class);
        String receivedNumber1 = getIntent().getStringExtra("numberKey1");
        String receivedNumber2 = getIntent().getStringExtra("numberKey2");

       if(receivedNumber1 == null || receivedNumber2==null){
           startActivity(intent2);
           Toast.makeText(getApplicationContext(), "You should enter some numbers first!", Toast.LENGTH_LONG).show();
       }
       else{
           float nr1 = Float.parseFloat(receivedNumber1);
           float nr2 = Float.parseFloat(receivedNumber2);
           float resultToSend = nr1 + nr2;
           intent2.putExtra("resultKey", resultToSend);
           startActivity(intent2);
       }
     }

    public void onClickSubstract(View view){
        Intent intent2 = new Intent(this, MainActivity.class);
        String receivedNumber1 = getIntent().getStringExtra("numberKey1");
        String receivedNumber2 = getIntent().getStringExtra("numberKey2");

        if(receivedNumber1 == null || receivedNumber2==null){
            startActivity(intent2);
            Toast.makeText(getApplicationContext(), "You should enter some numbers first!", Toast.LENGTH_LONG).show();
        }
        else{
            float nr1 = Float.parseFloat(receivedNumber1);
            float nr2 = Float.parseFloat(receivedNumber2);
            float resultToSend = nr1 - nr2;
            intent2.putExtra("resultKey", resultToSend);
            startActivity(intent2);
        }
    }

    public void onClickMultiply(View view){
        Intent intent2 = new Intent(this, MainActivity.class);
        String receivedNumber1 = getIntent().getStringExtra("numberKey1");
        String receivedNumber2 = getIntent().getStringExtra("numberKey2");

        if(receivedNumber1 == null || receivedNumber2 == null){
            startActivity(intent2);
            Toast.makeText(getApplicationContext(), "You should enter some numbers first!", Toast.LENGTH_LONG).show();
        }
        else{
            float nr1 = Float.parseFloat(receivedNumber1);
            float nr2 = Float.parseFloat(receivedNumber2);
            float resultToSend = nr1 * nr2;
            intent2.putExtra("resultKey", resultToSend);
            startActivity(intent2);
        }
    }

    public void onClickDivide(View view) {
        Intent intent2 = new Intent(this, MainActivity.class);
        String receivedNumber1 = getIntent().getStringExtra("numberKey1");
        String receivedNumber2 = getIntent().getStringExtra("numberKey2");

        float nr1 = Float.parseFloat(receivedNumber1);
        float nr2 = Float.parseFloat(receivedNumber2);

        if (nr2 == 0) {
            Toast.makeText(getApplicationContext(), "You cannot divide by 0!", Toast.LENGTH_LONG).show();
            startActivity(intent2);
        }
        else{
            float resultToSend = nr1 / nr2;
            intent2.putExtra("resultKey", resultToSend);
        }

        startActivity(intent2);
    }
}