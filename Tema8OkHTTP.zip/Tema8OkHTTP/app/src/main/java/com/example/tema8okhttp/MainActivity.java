package com.example.tema8okhttp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private TextView jsonDataTV, convertedValueTV;
    private EditText numberToConvertInput;

    //Avand in vedere ca JSON-ul indicat in documentul de pe kb nu merge, am folosit alt json cu cursul valutar,
    //insa nu are moneda MDL, astfel am folosit alta moneda in schimb, dolarul canadian CAD
    String jsonURL ="https://api.freecurrencyapi.com/v1/latest?apikey=COH46J6gDuOSZFh6Dz8aFURzHiuaQ4193UPEVkI6&currencies=EUR%2CUSD%2CCAD%2CGBP&base_currency=RON";
            //"http://www.floatrates.com/daily/ron.json";  //NU MERGE JSONUL !!! Nu poate fi accesat din android studio
    // "https://reqres.in/api/users/2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        jsonDataTV = findViewById(R.id.jsonDataTV);
        convertedValueTV = findViewById(R.id.convertedValueTV);
        numberToConvertInput = findViewById(R.id.numberToConvertInput);
    }

    public void onClickGetData(View view){
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(jsonURL).build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.i(TAG, "onFailure: am ajuns in failure");
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                String receivedData = response.body().string();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.i(TAG, "run: porneste");
                            //JSONObject jsonObject = new JSONObject(jsonURL.toString());
                           //jsonDataTV.setText("aici am primit: " + jsonObject.getJSONObject("eur").getString("rate"));
                            jsonDataTV.setText(receivedData);

//                        try {   //variante in care am incercat sa preiau de la jsonul respectiv, dar nu merg
//                            // Parse the JSON data
//                            JSONObject json = new JSONObject(jsonURL);
//
//                            // Print the data to the log
//                            Log.d("JSON Data", json.toString(4));
//                        } catch (JSONException e) {
//                            // If there is an error parsing the JSON, print the error to the log
//                            Log.i("JSON Parsing Error", e.getMessage());
//                        }
                    }
                });
            }
        });
    }

    public void onClickTrimEUR(View view){
        if(jsonDataTV != null){
            String data = jsonDataTV.getText().toString();
            try {
                String initialNr = numberToConvertInput.getText().toString();
                float initialNrFloat = Float.parseFloat(initialNr);
                JSONObject jsonObject = new JSONObject(data);
                float convertedEURvalue = (initialNrFloat * Float.parseFloat(jsonObject.getJSONObject("data").getString("EUR")));
                convertedValueTV.setText("Suma convertita: " + convertedEURvalue + "EUR");

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public void onClickTrimUSD(View view){
        if(jsonDataTV != null){
            String data = jsonDataTV.getText().toString();
            try {
                String initialNr = numberToConvertInput.getText().toString();
                float initialNrFloat = Float.parseFloat(initialNr);
                JSONObject jsonObject = new JSONObject(data);
                float convertedEURvalue = (initialNrFloat * Float.parseFloat(jsonObject.getJSONObject("data").getString("USD")));
                convertedValueTV.setText("Suma convertita: " + convertedEURvalue + "USD");

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public void onClickTrimGBP(View view){
        if(jsonDataTV != null){
            String data = jsonDataTV.getText().toString();
            try {
                String initialNr = numberToConvertInput.getText().toString();
                float initialNrFloat = Float.parseFloat(initialNr);
                JSONObject jsonObject = new JSONObject(data);
                float convertedEURvalue = (initialNrFloat * Float.parseFloat(jsonObject.getJSONObject("data").getString("GBP")));
                convertedValueTV.setText("Suma convertita: " + convertedEURvalue + "GBP");

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public void onClickTrimCAD(View view){
        if(jsonDataTV != null){
            String data = jsonDataTV.getText().toString();
            try {
                String initialNr = numberToConvertInput.getText().toString();
                float initialNrFloat = Float.parseFloat(initialNr);
                JSONObject jsonObject = new JSONObject(data);
                float convertedEURvalue = (initialNrFloat * Float.parseFloat(jsonObject.getJSONObject("data").getString("CAD")));
                convertedValueTV.setText("Suma convertita: " + convertedEURvalue + "CAD");

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}